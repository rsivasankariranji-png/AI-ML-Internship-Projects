# 🤖 Buddy AI Assistant

Buddy AI Assistant is a local desktop AI assistant with memory.

## Main Features
- Offline AI conversation using Ollama + LLaMA 3.2
- SQLite-based conversation memory
- Tamil + English mixed conversation
- Text-to-speech output
- Task management
- YouTube search
- Screenshot capture
- Screen recording

## Technology Stack
- Python
- Ollama
- LLaMA 3.2
- SQLite
- pyttsx3
- OpenCV
- NumPy
- PyAutoGUI
- Requests

## Local Windows Setup

1. Install Python 3.10+.
2. Install Ollama.
3. Download the LLaMA 3.2 model:
   `ollama pull llama3.2`
4. Install Python packages:
   `pip install -r requirements.txt`
5. Run:
   `python buddy_ai.py`

## Important
The main project is designed for a local desktop environment. Features such as screenshot,
screen recording, text-to-speech, and the Ollama localhost API are intended for the local PC.

For Google Colab, use the included `Buddy_AI_Colab.ipynb`. Colab is mainly useful for
testing the AI/memory portion; desktop-specific features are not equivalent to running on Windows.
