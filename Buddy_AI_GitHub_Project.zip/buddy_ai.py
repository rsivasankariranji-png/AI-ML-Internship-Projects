# Buddy AI Assistant
# Secure Offline Desktop AI Assistant with Memory
# Based on the final year project report

import pyttsx3
import datetime
import time
import webbrowser
import pyautogui
import cv2
import numpy as np
import requests
import sqlite3
import os

# ================== VOICE ENGINE ==================
try:
    engine = pyttsx3.init()
    engine.setProperty("rate", 160)
except Exception:
    engine = None

def speak(text):
    if engine is not None:
        try:
            engine.say(text)
            engine.runAndWait()
        except Exception:
            pass

# ================== DATABASE (MEMORY) ==================
conn = sqlite3.connect("buddy_memory.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS memory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_text TEXT,
    ai_text TEXT,
    time TEXT
)
""")
conn.commit()

def save_memory(user, ai):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cursor.execute(
        "INSERT INTO memory (user_text, ai_text, time) VALUES (?, ?, ?)",
        (user, ai, timestamp)
    )
    conn.commit()

def recall_memory():
    cursor.execute(
        "SELECT user_text, ai_text FROM memory ORDER BY id DESC LIMIT 5"
    )
    rows = cursor.fetchall()

    memory_text = ""
    for user_text, ai_text in rows:
        memory_text += f"User: {user_text}\nBuddy: {ai_text}\n"

    return memory_text

# ================== TASK STORAGE ==================
tasks = []

# ================== SCREEN RECORD ==================
def screen_record(duration):
    screen_size = pyautogui.size()
    fourcc = cv2.VideoWriter_fourcc(*"XVID")
    filename = f"record_{int(time.time())}.avi"

    out = cv2.VideoWriter(
        filename,
        fourcc,
        5.0,
        screen_size
    )

    start_time = time.time()

    while time.time() - start_time < duration:
        img = pyautogui.screenshot()
        frame = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        out.write(frame)

    out.release()
    return filename

# ================== OLLAMA AI ==================
def ollama_chat(prompt):
    try:
        memory = recall_memory()

        system_prompt = f"""
You are Buddy — a friendly and smart Tamil-English AI assistant.
You remember previous conversations.
You speak in simple Tamil + English mix.
Be supportive and helpful.

Conversation Memory:
{memory}

User: {prompt}
Buddy:
"""

        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "llama3.2",
                "prompt": system_prompt,
                "stream": False
            },
            timeout=60
        )

        response.raise_for_status()
        return response.json()["response"].strip()

    except Exception as e:
        return "⚠️ Ollama not responding. Check if Ollama is running."

# ================== START SCREEN ==================
print("""
╔════════════════════════════════════╗
║        🤖 BUDDY AI ASSISTANT       ║
║        Offline + Memory Enabled    ║
╚════════════════════════════════════╝
""")

speak("Buddy is online")

# ================== MAIN LOOP ==================
while True:
    user_input = input("\nYou: ").strip()

    if user_input == "":
        continue

    user = user_input.lower()

    # -------- EXIT --------
    if user in ["exit", "bye", "quit"]:
        speak("Bye da. I will remember you.")
        print("\n👋 Buddy Closed")
        break

    # -------- DATE / TIME --------
    elif "date" in user or "time" in user:
        now = datetime.datetime.now().strftime("%d %B %Y %I:%M %p")
        print(now)
        speak(now)

    # -------- TASK ADD --------
    elif user.startswith("add task"):
        task = user_input[8:].strip()

        if task:
            tasks.append(task)
            print("✔ Task added:", task)
            speak("Task added")
        else:
            print("Please enter a task.")

    # -------- TASK SHOW --------
    elif "show task" in user:
        if not tasks:
            print("No tasks available.")
            speak("No tasks")
        else:
            print("\nYour Tasks:")
            for i, task in enumerate(tasks, 1):
                print(i, task)
            speak("Showing tasks")

    # -------- TASK DELETE --------
    elif user.startswith("delete task"):
        try:
            number = int(user.split()[-1])

            if 1 <= number <= len(tasks):
                removed = tasks.pop(number - 1)
                print("Deleted:", removed)
                speak("Task deleted")
            else:
                print("Invalid task number.")

        except ValueError:
            print("Invalid task number.")

    # -------- YOUTUBE --------
    elif user.startswith("youtube"):
        query = user_input[7:].strip()

        if query:
            webbrowser.open(
                "https://www.youtube.com/results?search_query=" + query.replace(" ", "+")
            )
            speak("Opening YouTube")
        else:
            print("Please enter a YouTube search query.")

    # -------- SCREENSHOT --------
    elif "screenshot" in user:
        filename = f"shot_{int(time.time())}.png"
        pyautogui.screenshot(filename)
        print("Saved:", filename)
        speak("Screenshot taken")

    # -------- SCREEN RECORD --------
    elif "screen record" in user:
        try:
            seconds = int(input("Enter recording duration in seconds: "))

            if seconds <= 0:
                raise ValueError

            filename = screen_record(seconds)
            print("Saved:", filename)
            speak("Recording completed")

        except ValueError:
            print("Invalid duration.")

    # -------- AI CHAT --------
    else:
        reply = ollama_chat(user_input)
        print("\n🤖 Buddy:", reply)
        speak(reply)
        save_memory(user_input, reply)

conn.close()
